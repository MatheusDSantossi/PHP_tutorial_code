#### The exercise for the PHP course "Learn PHP The Right Way" lesson 2.1.

https://youtu.be/I_9-xWmkh28

---
#### Course Playlist
https://www.youtube.com/watch?v=sVbEyFZKgqk&list=PLr3d3QYzkw2xabQRUpcZ_IBk9W50M9pe-
